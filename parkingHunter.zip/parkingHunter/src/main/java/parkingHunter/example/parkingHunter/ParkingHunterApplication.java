package parkingHunter.example.parkingHunter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingHunterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingHunterApplication.class, args);
	}

}
