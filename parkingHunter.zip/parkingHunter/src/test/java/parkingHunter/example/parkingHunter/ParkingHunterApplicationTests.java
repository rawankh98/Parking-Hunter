package parkingHunter.example.parkingHunter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingHunterApplicationTests {

	@Test
	void contextLoads() {
	}

}
